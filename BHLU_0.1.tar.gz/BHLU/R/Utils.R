
'BHLU'      = function(X, Z, priormean, priorvar, Algo, df, Iterations, burn, thin = 1, spp_names, sample_names){
  n  = dim(Z)[1]
  r1 = dim(Z)[2]
  p  = dim(X)[2]
  r2 = dim(X)[1]
  
  if(n < r1){
    stop(cat('Number of observations :', n, ' should be at least equal to the number of markers: ', r1, '\n'))
  }
  if(r1 != r2){
    stop(cat('Number of markers in response: ', r1, 'does not match number of markers in source: ', r2, '\n'))
  }
  if((Algo == "GD" | Algo == "GC"| Algo == "CG" | Algo == "DG") & (!is.null(priorvar) & !is.null(priormean))){
    p2 = length(priormean)
    p3 = dim(priorvar)[1]
    p4 = dim(priorvar)[2]
    if(p2 != p){
      stop(cat('Prior mean vector has: ', p2, 'elements while source matrix has: ', p,' columns \n'))
    }
    if((p3 != p) | (p3 != p2) | (p3 != p4)){
      stop(cat('Dimensions of prior mean vector and prior mean variance matrix do not match\n'))
    }
  }
  if(Algo == "DU" | Algo == "UD" | Algo == "CU" | Algo == "UC"){
    if(!is.null(priormean) | !is.null(priorvar)){
      cat(stop('Using Uniform priors, prior mean and variance not needed'))
    }
  }
  if(Iterations < 2){
    stop(cat('Number of iterations should be greater than 1\n'))
  }
  if(burn > Iterations){
    stop(cat('Number of iterations should be greater than number of burn-in rounds\n'))
  }
  if(df < (r1 + 2)){
    stop(cat('Prior degrees of freedom should be at least ', r1 + 2, "\n"))
  }
  if(is.null(spp_names)){
    spp_names = c(paste("spp", 1:p, sep = ''))
  }
  if(is.null(sample_names)){
    sample_names = c(paste("Id", 1:n, sep = ''))
  }
  if(!is.null(spp_names) & (length(spp_names) != p)){
    stop(cat('Number of column names should equal number of columns'))
  }
  if(!is.null(sample_names) & length(sample_names) != n){
    stop(cat('Number of row names should equal number of rows'))
  }
  if(Algo == "DU" | Algo == 'DG' | Algo == "UD" | Algo == "GD"){
    cv = "diagonal"
  } else{
    cv = 'full (un/symm)'
  } 
  if(Algo == "DU" | Algo == "CU" | Algo == "UD" | Algo == "UC"){
    pm = "uniform"
  } else {
    pm = "gaussian"
  }
  cat('-------------------------------------------------------------------------------------------------\n')
  cat('Bayesian hierarchical linear unmixing with ', pm, 'priors and ', cv, 'covariance matrix \n')
  cat('-------------------------------------------------------------------------------------------------\n')
  M                    = X
  Y                    = t(Z)
  q                    = priormean
  V                    = priorvar
  nu                   = df
  nIter                = Iterations
  burnIn               = burn
  thin                 = thin
  if(Algo == "DU" | Algo == "UD"){
    fit                = BHUDunif(M, Y, nu, nIter)
  } else if(Algo == "CU" | Algo == "UC"){
    fit                = BHUunif(M, Y, nu, nIter)
  } else if(Algo == "DG" | Algo == "GD"){
    fit                  = BHUDgauss(M, Y, q, V, nu, nIter)
  } else if(Algo == "GC" | Algo == "CG"){
    fit                  = BHUgauss(M, Y, q, V, nu, nIter)
  } else{
    cat(stop("Algorithm not recognized. Should be: DU, CU, GU, GC"))
  }
  Temp                 = fit$Theta
  thining              = seq(burnIn + 1, nIter, by = thin)
  Theta                = Temp[thining , ,]
  dimnames(Theta)[[2]] = spp_names
  dimnames(Theta)[[3]] = sample_names
  Means                = t(colMeans(Theta))
  colnames(Means)      = spp_names
  rownames(Means)      = sample_names
  return(list('Theta' = Theta, 'Means' = Means))
}

"nnlsWax"   = function(M, Y){
  library(nnls)
  Tmp   = apply(Y, 2, function(Y.col) nnls(M, Y.col)$x)
  Theta = apply(Tmp, 2, function(Tmp.col) Tmp.col/sum(Tmp.col)) 
  return(Theta)
}

'summaryBHLU' = function(Theta){
  p   = dim(Theta)[2]
  Out = list()
  for(j in 1:p){
    tmp      = mcmc(Theta[, j, ])
    Out[[j]] = summary(tmp)
  }
  return(Out)
}