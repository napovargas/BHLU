#include <RcppArmadillo.h>
#include <cmath>
#include <limits>
#include <time.h>

// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

// Set difference function
arma::uvec mysetdiff(arma::uvec& x, arma::uvec& y){

  x = arma::unique(x);
  y = arma::unique(y);
  for (size_t j = 0; j < y.n_elem; j++) {
    arma::uvec q1 = arma::find(x == y[j]);
    x.shed_row(q1(0));
  }

  return x;
}

// Positive Gaussian distribution 
double rpnorm(double mean, double dev){
const double  A  = 1.136717791056118;
const double pi = M_PI;
double var = dev*dev;
double v = std::numeric_limits<double>::quiet_NaN();
double mA = (1 - A*A)/A*dev;
double mC = dev*std::sqrt(pi/2.0);
double a = 0;
double z = 0;
double rho = 0;
double r = 0;
double u = 0;
double g = 0;

    while(std::isnan(v)){
        if (mean < mA){
            a 	= (-mean + sqrt(mean*mean + 4.0*var))/2/var;
            z 	= -log(1.0 - runif(1)[0])/a;
            rho = exp(-(z - mean)*(z - mean)/2.0/var - a*(mean - z + a*var/2.0));
        }
        
        else if(mean <= 0){
            z 	= std::abs(rnorm(1)[0])*dev + mean;
			rho = (z >= 0.0)?1.0:0.0;
        }
        
        else if(mean < mC){
            r 	= (runif(1)[0] < mean/(mean + std::sqrt(pi/2.0)*dev))?1.0:0.0;
			u 	= runif(1)[0]*mean;
			g 	= std::abs(rnorm(1)[0]*dev) + mean;
			z 	= r*u + (1.0 - r)*g;
			rho = r*exp(-(z - mean)*(z - mean)/2.0/var) + (1.0 - r);
        }
        
        else {
            z 	= rnorm(1)[0]*dev + mean;
			rho = (z >= 0)?1.0:0.0;
        }
        
        if(runif(1)[0] < rho){
            v = z;
        }
    }
    return (v);
}

// Sequence function
arma::uvec sequence(arma::uword from, arma::uword to){
    arma::uword nelems = to - from + 1;
    arma::uvec x(nelems);
    for (arma::uword i = 0; i < nelems; i++){
        x(i) = from + i;
    }
    return x;
}

arma::vec Dirichlet(arma::vec alpha){
    arma::uword k = alpha.n_rows;
    arma::vec y = zeros(k);
    arma::vec x = zeros(k);
    for(uword j = 0; j < k; j++){
        y(j) = rgamma(1, alpha(j), 1)[0];
    }
    for(uword i = 0; i < k; i++){
        x(i) = y(i)/arma::accu(y);
    }
    return(x);
}

mat Wishart(int const& nu, mat const& V){

  int m = V.n_rows;
  mat T = zeros(m,m); 
  mat R = zeros(m,m);
  for(int i = 0; i < m; i++) {
    T(i,i) = sqrt(rchisq(1,nu-i)[0]); 
  }
   
  for(int j = 0; j < m; j++) {  
    for(int i = j+1; i < m; i++) {    
      T(i,j) = rnorm(1)[0]; 
    }}
  
  mat C = trans(T)*chol(V); 
  
    return R = trans(C)*C;
}

mat InverseWishart(int const& nu, mat const& V){ 

  int m = V.n_rows;
  mat T = zeros(m,m);
  mat IR = zeros(m,m);
  for(int i = 0; i < m; i++) {
    T(i,i) = sqrt(rchisq(1,nu-i)[0]);
  }
  
  for(int j = 0; j < m; j++) {  
    for(int i = j+1; i < m; i++) {    
      T(i,j) = rnorm(1)[0]; 
    }}
  
  mat C = trans(T)*chol(V);
  mat CI = solve(trimatu(C),eye(m,m));  

    return IR = CI*trans(CI);
}

/* Update lambda parameter */
double update_lambda(arma::vec sigma, int nu){
  int d = sigma.n_elem;
  double shape = d*(double)nu/2;
  double invscale;
  double lambda;
  invscale = (nu*0.5)*accu(arma::pow(sigma, -1));
  lambda = rgamma(1, shape, 1/invscale)[0];
  return lambda;
}

/* Update vector of marker variances */
arma::vec update_sigma(arma::mat Theta, arma::mat Y, arma::mat M, double lambda, int nu){
  uword n = Y.n_cols;
  uword r = Y.n_rows;
  double N = n;
  arma::mat Residual(r, n);
  arma::mat Res_sq(r, n);
  arma::mat Tmp(n, r);
  arma::vec scale(1);
  arma::vec sigma(r);
  
  Residual = Y - M*arma::trans(Theta);
  for(uword i = 0; i < r; i++){
    Res_sq.row(i) = pow(Residual.row(i),2); 
  }
  for(uword i = 0; i < n; i++){
    for(uword j = 0; j < r; j++){
      Tmp(i,j) = Res_sq(j,i);
    }  
  }
  
  for (uword k = 0; k < r; k++){
    scale = (nu*lambda)/(N + nu) + (1/(N + nu))*(sum(Tmp.col(k)));
    sigma(k) = ((N + nu)*scale(0))/(R::rchisq(N + nu)); 
  }
  
  return (sigma);
}

/* Truncated Gaussian  distribution */
/* Adapted from Matlab Code provided by Nicolas Dobigeon */
double TruncGauss(double x_old, double mu, double sigma, double mum, double mup){
  double sigma2;
  int accept;
  int compt;
  double x;
  double z;
  double d0;
  sigma2 		= sigma*sigma;
  mup 			= (mup - mu)/sigma;
  mum 			= (mum - mu)/sigma;

  accept 		= 0;
  compt 		= 0;
  x 			= x_old;
  while ((accept == 0) && (compt < 200)) {
    compt++;
    z = runif(1)[0]*(mup - mum) + mum;
    if (0.0 < mum) {
      d0 = exp((mum * mum - z * z) / 2.0);
    } else if (mup < 0.0) {
      d0 = exp((mup * mup - z * z) / 2.0);
    } else {
      d0 = exp(-(z * z) / 2.0);
    }

    if (runif(1)[0] < d0) {
      x 		= z;
      accept 	= 1;
    }
  }

  return (x * sqrt(sigma2) + mu) * (double)accept + x_old * (1.0 - (double)accept);
}

/* Metropolis step for truncated Gaussian */
/* Adapted from Matlab Code provided by Nicolas Dobigeon */
double TruncGaussMH(double X, double Mu, double Sigma, double Mum, double Mup){
  
  double Mu_new;
  double Mup_new;
  double Z;
  double Y;
  bool b0;
  double delta;
  Mu_new 	= Mu - Mum;
  Mup_new 	= Mup - Mum;
  if (Mu < Mup) {
    Z 		= rpnorm(Mu_new, Sigma);
  } else {
    delta 	= Mu_new - Mup_new;
    Mu_new 	= -delta;
    Z 		= rpnorm(Mu_new, Sigma);
    Z 		= -(Z - Mup_new);
  }

  Z += Mum;
  if ((Z <= Mup) && (Z >= Mum)) {
    b0 = true;
  } else {
    b0 = false;
  }
  
  Y = Z * (double)b0 + X*(double)!b0;
  return(Y);
}

/*     Sampling from Gaussian truncated on a simplex     */
/* Adapted from Matlab Code provided by Nicolas Dobigeon */
vec MVGSimplex(vec S, vec const& Mean, mat const& Var){
  vec Mu            = Mean;
  uword p           = Mu.n_elem;
  uword j           = 0;
  vec Mu_sv         = zeros(p);
  vec Var_sv        = zeros(p);
  vec Sd_sv         = zeros(p);
  vec Sj;
  vec Muj;
  vec Rv(p - 1);
  uvec P            = sequence(1, p);
  uvec shuffledP    = shuffle(P);
  mat vecSigma      = zeros(p - 1, p);
  mat Rm            = zeros(p, p);
  cube matSigma     = zeros(p - 1, p - 1, p);
  
  for(uword r = 0;r < p; r++){
    Rm = Var;
    Rm.shed_row(r);
    Rv = Rm.col(r);
    Rm.shed_col(r);
    matSigma.slice(r) = inv(Rm);
    vecSigma.col(r) = Rv;
  } 
        for(uvec::iterator jit = shuffledP.begin(); jit != shuffledP.end(); jit++){
            j               	= (int)*jit - 1;
            Sj              	= S;
            Sj.shed_row(j);
            Muj             	= Mu;
            Muj.shed_row(j);
            Mu_sv(j)        	= (Mu(j) + (trans(vecSigma.col(j))*matSigma.slice(j)*(Sj - Muj)))[0];
            Var_sv(j) 			= (Var(j, j) - (trans(vecSigma.col(j))*matSigma.slice(j)*vecSigma.col(j)))[0];
            Sd_sv(j) 			= sqrt(std::abs(Var_sv(j)));
            S(j) 				= TruncGaussMH(S(j), Mu_sv(j), Sd_sv(j), 0.0, (1 - sum(S) + S(j)));

        }
  return(S);
}


// Updating proportion means 
arma::vec update_theta_gauss(arma::vec ThetaStar, arma::mat M, arma::mat Sigma, arma::vec y, arma::mat Psi, arma::uvec estim, arma::uvec last, 
                      arma::mat Mstar, arma::vec mp, arma::vec One, arma::vec qStar, arma::mat Vstar){
    arma::uword p               = M.n_cols;
    arma::vec theta_old(1);
    arma::vec tmp1              = zeros(1);
    arma::vec Mean              = zeros(p - 1);
    arma::vec Mu                = zeros(p - 1);
    arma::vec MeanStar          = zeros(p - 1);
    arma::vec Theta_p;
    arma::mat Sigma_i           = Sigma;
    arma::mat Psi_i             = Psi;
    arma::mat PsiStar_i         = inv(Psi_i) + inv(Vstar);
    if (p == 2){
        theta_old               = ThetaStar.elem(estim);
        Mean                    = (1/Psi_i(0,0))*trans(Mstar - mp*trans(One))*solve(Sigma_i, y - mp);
        MeanStar                = (1/PsiStar_i(0,0))*((1/Psi_i(0,0))*Mean(0) + (1/Vstar(0,0))*qStar(0));
        Mu                      = TruncGauss(theta_old(0), MeanStar(0), sqrt(PsiStar_i(0, 0)), 0.0, 1.0);
        ThetaStar.elem(estim)   = Mu;
        ThetaStar.elem(last)    = 1 - Mu;
    }
    else {
        Mean                    = inv(Psi_i)*trans(Mstar - mp*trans(One))*solve(Sigma_i, y - mp); 
        MeanStar                = inv(PsiStar_i)*(solve(Psi_i, Mean) + solve(Vstar, qStar));
        Mu                      = MVGSimplex(ThetaStar.elem(estim), MeanStar, PsiStar_i);
        Theta_p << 1 - accu(Mu);
        ThetaStar.elem(estim)   = Mu;
        ThetaStar.elem(last)    = max(Theta_p, tmp1);
    }
    return (ThetaStar);
}

/* Updating means under uniform prior (a.k.a. Dirichlet(alpha = 1,...,1)) */
arma::vec update_theta_unif(arma::vec ThetaStar, arma::mat M, arma::mat Sigma, arma::vec y, arma::mat Psi, arma::uvec estim, arma::uvec last, 
                      arma::mat Mstar, arma::vec mp, arma::vec One){
    uword p                 = M.n_cols;
    vec theta_old(1);
    vec tmp1 = zeros(1);
    vec Mean                = zeros(p - 1);
    vec Mu                  = zeros(p - 1);
    vec Theta_p;
    
    mat Sigma_i = Sigma;
    mat Psi_i = Psi;
    if (p == 2){
        theta_old               = ThetaStar.elem(estim);
        Mean                    = (1/Psi_i(0,0))*trans(Mstar - mp*trans(One))*solve(Sigma_i, y - mp);
        Mu                      = TruncGauss(theta_old(0), Mean(0), sqrt(1/Psi_i(0, 0)), 0.0, 1.0);
        ThetaStar.elem(estim)   = Mu;
        ThetaStar.elem(last)    = 1 - Mu;
    }
    else {
        Mean                    = solve(Psi_i, eye(p - 1, p - 1))*trans(Mstar - mp*trans(One))*solve(Sigma_i, y - mp);
        Mu                      = MVGSimplex(ThetaStar.elem(estim), Mean, solve(Psi_i, eye(p - 1, p - 1)));
        Theta_p << 1 - accu(Mu);
        ThetaStar.elem(estim)   = Mu;
        ThetaStar.elem(last)    = max(Theta_p, tmp1);
    }

    return (ThetaStar);
}

/*----------------------------------------------------------------------------------------------*/
/* Main function to perform BHLU under uniform priors and diagonal covariance matrix for errors */
/*----------------------------------------------------------------------------------------------*/

// [[Rcpp::export]]
List BHUDunif(mat M, mat Y, double nu, uword nIter){
  /* Integer variables and vectors */
  uword r             = M.n_rows;
  uword p             = M.n_cols;
  uword nAnim         = Y.n_cols;
  uvec plants;
  uvec tmp;
  uvec lastj;
  uvec inTheta;
  uvec estim;
  uvec last;
  vec Theta_p;
  
  /*Real variables vectors and Matrices */
  double lambda = 1;
  double ttime;
  double pct          = 0;
  clock_t start;
  clock_t end;
  mat Mstar;
  mat mp;
  mat Psi;
  mat Cinv;
  vec tmp1          = zeros(1);
  mat One                 = ones <mat> (p - 1, 1);
  
  /* Initial values */
  plants                  = sequence(1, p);
  vec init(p);
  mat Theta         = ones(p, nAnim)/p;
  for (uword t = 0; t < nAnim; t++){
   init          = ones(p, 1);
   Theta.col(t)  = Dirichlet(init);
  }
  mat store_Sigma   = zeros(nIter, r);
  mat store_lambda  = zeros(nIter, 1);
  mat Sigma = eye(r,r)*nu;
  vec sigma = ones(r);
  
  
  Rcpp::Rcout.precision(2);
  cube store_Theta  = zeros(nIter, p, nAnim);
  List Out;
  Cinv          = inv(trans(M)*M);
  
  /* For updating Theta_i */
  vec ThetaStar;
  
  start = clock();
  
  for(uword iter = 0; iter < nIter; iter++){
      tmp                     = arma::shuffle(plants);
      lastj                   = tmp(0);
      inTheta                 = mysetdiff(tmp, lastj);
      estim                   = inTheta -  1;
      last                    = lastj - 1;
      Mstar                   = M.cols(estim);
      mp                      = M.cols(last); 
      Psi                     = trans(Mstar - mp*trans(One))*inv(Sigma)*(Mstar - mp*trans(One));
      for(uword i = 0; i < nAnim; i++){
      ThetaStar                                   = update_theta_unif(Theta.col(i), M, Sigma, Y.col(i), Psi, estim, last, Mstar, mp, One); 
      store_Theta(span(iter), span::all, span(i)) = ThetaStar;
      Theta.col(i)            = ThetaStar;
      }
    

    sigma                 = update_sigma(trans(Theta), Y, M, lambda, nu);
    Sigma                 = diagmat(sigma);
    lambda                = update_lambda(sigma, nu);
    store_Sigma.row(iter) = trans(sigma);
    store_lambda(iter)    = lambda;
    if(iter % 1000 == 0){
        Rcpp::checkUserInterrupt();
        pct = (double)iter/(double)nIter;
        Rcpp::Rcout << " Iteration " << iter << "/" << nIter << " (" << (pct*100.00) << "%) "<< std::endl;
      }
    
  }
  end = clock();
  ttime = ((double) (end - start)) / CLOCKS_PER_SEC;
  Rcpp::Rcout << "                                               " << std::endl;
  Rcpp::Rcout << " Wrapping up! " << std::endl;
  Rcpp::Rcout << "                                               " << std::endl;
  Rcpp::Rcout << nIter << " iterations in " << ttime << " seconds" << std::endl;
  
  Out["Theta"]        = store_Theta;
  Out["MeanSigma"]    = store_Sigma;
  Out["SdSigma"]      = stddev(store_Sigma, 0, 0);
  Out["MeanXi"]       = mean(store_lambda);
  Out["SdXi"]         = stddev(store_lambda);
  Out["Elapsed time"] = ttime;
  return(wrap(Out));
}

/*------------------------------------------------------------------------------------------*/
/* Main function to perform BHLU under uniform priors and full covariance matrix for errors */
/*------------------------------------------------------------------------------------------*/

// [[Rcpp::export]]
List BHUunif(mat const& M, mat const& Y, double const& nu, uword const& nIter){//mat const& Omega, double const& gamma, uword const& nIter){
  /* Integer variables and vectors */
  uword r             = M.n_rows;
  uword p             = M.n_cols;
  uword nAnim         = Y.n_cols;
  uvec plants;
  uvec tmp;
  uvec lastj;
  uvec inTheta;
  uvec estim;
  uvec last;
  
  /* Real variables */
  double ttime      = 0;
  double pct        = 0;
  clock_t start;
  clock_t end;
  vec Theta_p;
  mat Mstar;
  mat mp;
  mat Psi;
  mat Cinv;
  vec tmp1          = zeros(1);
  mat One           = ones <mat> (p - 1, 1);
  plants            = sequence(1, p);
  
  /* Initial values */
  vec init(p);
  mat Theta         = ones(p, nAnim)/p;
  for (uword t = 0; t < nAnim; t++){
   init          = ones(p, 1);
   Theta.col(t)  = Dirichlet(init);
  }
  mat store_Sigma   = zeros(nIter, r*r);
  mat store_Xi      = zeros(nIter, r);
  vec store_DIC     = zeros(nIter, 1);
  cube store_Theta  = zeros(nIter, p, nAnim);
  Rcpp::Rcout.precision(2);
  List Out;
  
  /* For updating Theta_i */
  vec ThetaStar;
  
  /* For updating Sigma */
  mat Sigma     = InverseWishart(nAnim + nu, eye(r, r)*nu);   
  mat Xi        = Sigma;
  mat R         = zeros <mat> (r, r);
  mat store_p   = zeros(nIter, p);
  Cinv          = inv(trans(M)*M);
  vec gamma     = zeros(r);
  mat Sigmainv  = Sigma;
  
  start = clock();
  
  for(uword iter = 0; iter < nIter; iter++){
    tmp                     = shuffle(plants);
    lastj                   = tmp(0);
    inTheta                 = mysetdiff(tmp, lastj);
    estim                   = inTheta -  1;
    last                    = lastj - 1;
    Mstar                   = M.cols(estim);
    mp                      = M.cols(last); 
    Psi                     = trans(Mstar - mp*trans(One))*inv(Sigma)*(Mstar - mp*trans(One));
    for(uword i = 0; i < nAnim; i++){
      ThetaStar                                   = update_theta_unif(Theta.col(i), M, Sigma, Y.col(i), Psi, estim, last, Mstar, mp, One); 
      store_Theta(span(iter), span::all, span(i)) = ThetaStar;
      Theta.col(i)                                = ThetaStar;
      R                                           = R  + ((Y.col(i) - M*ThetaStar)*trans(Y.col(i) - M*ThetaStar));
      }

      Sigma                 = InverseWishart(nAnim + nu, inv(R + Xi));
      Sigmainv              = inv(Sigma);
      for(uword k = 0; k < r; k++){
          gamma(k) = rgamma((double)nu*(double)r*0.5, 0.5*Sigmainv(k, k))[0];
      }
      Xi                    = diagmat(gamma);
      store_Sigma.row(iter) = vectorise(Sigma, 1); 
      store_Xi.row(iter)    = trans(Xi.diag()); 
      store_p.row(iter)     = trans(arma::mean(Theta, 1));
      R                     = zeros(r, r);
      
      if(iter % 1000 == 0){
        pct = (double)iter/(double)nIter;
        Rcpp::checkUserInterrupt();
        pct = (double)iter/(double)nIter;
        Rcpp::Rcout << " Iteration " << iter << "/" << nIter << " (" << (pct*100.00) << "%) "<< std::endl;
      }  
    }
    
    end = clock();
    ttime = ((double) (end - start)) / CLOCKS_PER_SEC;
    Rcpp::Rcout << "                                               " << std::endl;
    Rcpp::Rcout << " Wrapping up! " << std::endl;
    Rcpp::Rcout << "                                               " << std::endl;
    Rcpp::Rcout << nIter << " iterations in " << ttime << " seconds" << std::endl;
  
    Out["Theta"]        = store_Theta;
    Out["Forages"]      = store_p;
    Out["MeanSigma"]    = store_Sigma;
    Out["SdSigma"]      = stddev(store_Sigma, 0, 0);
    Out["MeanXi "]      = mean(store_Xi, 0);
    Out["SdXi"]         = stddev(store_Xi, 0, 0);
    Out["Elapsed time"] = ttime;
    return(wrap(Out));    
}

/*--------------------------------------------------------------------------------------------*/
/* Main function to perform BHLU with Gaussian priors and Diagonal Variance matrix for errors */
/*--------------------------------------------------------------------------------------------*/

// [[Rcpp::export]] 
List BHUDgauss(mat M, mat Y, vec const& q, mat const& V, double nu, uword nIter){
  /* Integer vectors and scalar variables */
  uword r             = M.n_rows;
  uword p             = M.n_cols;
  uword nAnim         = Y.n_cols;
  uvec plants;
  uvec tmp;
  uvec lastj;
  uvec inTheta;
  uvec estim;
  uvec last;
  
  /* Real variables */
  double lambda = 1;
  double ttime;
  double pct;
  clock_t start;
  clock_t end;
  
  /* Real vector variables */
  vec Theta_p;
  vec tmp1          = zeros(1);
  vec init(p);
  mat Mstar;
  mat mp;
  mat Psi;
  mat One           = ones <mat> (p - 1, 1);
  mat Theta         = ones(p, nAnim)/p;
  mat Cinv;
  
  /* Initial values */
  plants                  = sequence(1, p);
  for (uword t = 0; t < nAnim; t++){
   init          = ones(p, 1);
   Theta.col(t)  = Dirichlet(init);
  }
  vec sigma 		= ones(r);
  vec qStar         = q;
  mat store_Sigma   = zeros(nIter, r);
  mat store_lambda  = zeros(nIter, 1);
  mat Sigma 		= eye(r,r)*nu;
  mat Vstar         = V;
  cube store_Theta  = zeros(nIter, p, nAnim);
  List Out;

  Rcpp::Rcout.precision(2);
  /* For updating Theta_i */
  vec ThetaStar;
  Cinv          = inv(trans(M)*M);
  
  /* Start timing */
  start = clock();
  /* Main MCMC loop */
  for(uword iter = 0; iter < nIter; iter++){
      tmp                     = arma::shuffle(plants);
      lastj                   = tmp(0);
      inTheta                 = mysetdiff(tmp, lastj);
      estim                   = inTheta -  1;
      last                    = lastj - 1;
      Mstar                   = M.cols(estim);
      mp                      = M.cols(last); 
      Psi                     = trans(Mstar - mp*trans(One))*inv(Sigma)*(Mstar - mp*trans(One));
      qStar                   = q;
      Vstar                   = V;
      Vstar.shed_row(last[0]);
      Vstar.shed_col(last[0]);  
      qStar.shed_row(last[0]);
      
      for(uword i = 0; i < nAnim; i++){
      ThetaStar                                   = update_theta_gauss(Theta.col(i), M, Sigma, Y.col(i), Psi, estim, last, Mstar, mp, One, qStar, Vstar); 
      store_Theta(span(iter), span::all, span(i)) = ThetaStar;
      Theta.col(i)            = ThetaStar;
      }
    

    sigma                 = update_sigma(trans(Theta), Y, M, lambda, nu);
    Sigma                 = diagmat(sigma);
    lambda                = update_lambda(sigma, nu);
    store_Sigma.row(iter) = trans(sigma); 
    store_lambda(iter)    = lambda;
    if(iter % 1000 == 0){
        Rcpp::checkUserInterrupt();
        pct = (double)iter/(double)nIter;
        Rcpp::Rcout << " Iteration " << iter << "/" << nIter << " (" << (pct*100.00) << "%) "<< std::endl;
      }
    
  }
  end = clock();
  ttime = ((double) (end - start)) / CLOCKS_PER_SEC;
  Rcpp::Rcout << "                                               " << std::endl;
  Rcpp::Rcout << " Done! " << std::endl;
  Rcpp::Rcout << "                                               " << std::endl;
  Rcpp::Rcout << nIter << " iterations in " << ttime << " seconds" << std::endl;
  
  Out["Theta"]        = store_Theta;
  Out["MeanSigma"]    = store_Sigma;
  Out["SdSigma"]      = stddev(store_Sigma, 0, 0);
  Out["MeanXi"]       = mean(store_lambda);
  Out["SdXi"]         = stddev(store_lambda);
  Out["Elapsed time"] = ttime;
  return(wrap(Out));
}

/*-------------------------------------------------------------------------------------------*/
/* Main function to perform BHLU under Gaussian priors and Full covariance matrix for errors */
/*-------------------------------------------------------------------------------------------*/
// [[Rcpp::export]] 
List BHUgauss(mat const& M, mat const& Y, vec const& q, mat const& V, double const& nu, uword const& nIter){
  /* Integer variables */
  uword r             = M.n_rows;
  uword p             = M.n_cols;
  uword nAnim         = Y.n_cols;
  
  /* Real variables */
  double ttime        = 0;
  double pct          = 0;
  clock_t start;
  clock_t end;
  
  /* Integer and real vectors and Matrices */
  uvec plants;
  uvec tmp;
  uvec lastj;
  uvec inTheta;
  uvec estim;
  uvec last;
  vec Theta_p;
  vec tmp1          		= zeros(1);
  vec init(p);
  mat Mstar;
  mat mp;
  mat Psi;
  mat Cinv;
  mat One           		= ones <mat> (p - 1, 1);
  plants            		= sequence(1, p);
  mat Theta         		= ones(p, nAnim)/p;
  arma::vec qStar        	= q;
  arma::mat Vstar         	= V;
  Rcpp::Rcout.precision(2);
  for (uword t = 0; t < nAnim; t++){
   init          = ones(p, 1);
   Theta.col(t)  = Dirichlet(init);
  }
  mat store_Sigma   = zeros(nIter, r*r);
  mat store_Xi      = zeros(nIter, r);
  cube store_Theta  = zeros(nIter, p, nAnim);
  mat store_p       = zeros(nIter, p);
  List Out;
  
  /* For updating Theta_i */
  vec ThetaStar;
  
  /* For updating Sigma */
  mat Sigma     = InverseWishart(nAnim + nu, eye(r, r)*nu);   
  mat Xi        = Sigma;
  mat R         = zeros <mat> (r, r);
  Cinv          = inv(trans(M)*M);
  mat Sigmainv  = Sigma;
  vec gamma     = zeros(r);
  
  /* Start timing */
  start = clock();
  /* Main MCMC loop */
  for(uword iter = 0; iter < nIter; iter++){
    tmp                     = shuffle(plants);
    lastj                   = tmp(0);
    inTheta                 = mysetdiff(tmp, lastj);
    estim                   = inTheta -  1;
    last                    = lastj - 1;
    Mstar                   = M.cols(estim);
    mp                      = M.cols(last); 
    Psi                     = trans(Mstar - mp*trans(One))*inv(Sigma)*(Mstar - mp*trans(One));
    qStar         = q;
    Vstar         = V;
    Vstar.shed_row(last[0]);
    Vstar.shed_col(last[0]);  
    qStar.shed_row(last[0]); 
    
    for(uword i = 0; i < nAnim; i++){
      ThetaStar                                   = update_theta_gauss(Theta.col(i), M, Sigma, Y.col(i), Psi, estim, last, Mstar, mp, One, qStar, Vstar); 
      store_Theta(span(iter), span::all, span(i)) = ThetaStar;
      Theta.col(i)                                = ThetaStar;
      R                                           = R  + ((Y.col(i) - M*ThetaStar)*trans(Y.col(i) - M*ThetaStar)); 
      }
      
      Sigma                 = InverseWishart(nAnim + nu, inv(R + Xi));
      Sigmainv              = inv(Sigma);
      for(uword k = 0; k < r; k++){
          gamma(k) = rgamma((double)nu*(double)r*0.5, 0.5*Sigmainv(k, k))[0];
      }
      Xi                    = diagmat(gamma);
      store_Sigma.row(iter) = vectorise(Sigma, 1); 
      store_Xi.row(iter)    = trans(Xi.diag());  
      store_p.row(iter)     = trans(arma::mean(Theta, 1)); 
      R                     = zeros(r, r); 
      if(iter % 1000 == 0){
        Rcpp::checkUserInterrupt();
        pct = (double)iter/(double)nIter;
        Rcpp::Rcout << " Iteration " << iter << "/" << nIter << " (" << (pct*100.00) << "%) "<< std::endl;
      }  
    }
    
    end = clock();
    ttime = ((double) (end - start)) / CLOCKS_PER_SEC;
    Rcpp::Rcout << "                                               " << std::endl;
    Rcpp::Rcout << " Done! " << std::endl;
    Rcpp::Rcout << "                                               " << std::endl;
    Rcpp::Rcout << nIter << " iterations in " << ttime << " seconds" << std::endl;
  
    Out["Theta"]        = store_Theta;
    Out["Forages"]      = store_p;
    Out["MeanSigma"]    = store_Sigma;
    Out["SdSigma"]      = stddev(store_Sigma, 0, 0);
    Out["MeanXi "]      = mean(store_Xi, 0);
    Out["SdXi"]         = stddev(store_Xi, 0, 0);
    Out["Elapsed time"] = ttime;
    return(wrap(Out));    
}
